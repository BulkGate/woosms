<?php
namespace BulkGate\Extensions\IO;

use BulkGate, BulkGate\Extensions\Json;

/**
 * @author Lukáš Piják 2018 TOPefekt s.r.o.
 * @link https://www.bulkgate.com/
 */
class Response extends \stdClass
{
    public function __construct($data, $content_type)
    {
        if(is_string($data))
        {
            if($content_type === 'application/json')
            {
                try
                {
                    $result = Json::decode($data, Json::FORCE_ARRAY);

                    if(is_array($result))
                    {
                        $this->load((array) $result);
                    }
                }
                catch (BulkGate\Extensions\JsonException $e)
                {
                    throw new InvalidResultException('Json parse error: '. $data);
                }
            }
            elseif($content_type === 'application/zip')
            {
                $result = Json::decode(BulkGate\Extensions\Compress::decompress($data));

                if(is_array($result) || $result instanceof \stdClass)
                {
                    $this->load((array) $result);
                }
            }
            else
            {
                throw new InvalidResultException('Invalid content type'. $data);
            }
        }
        else
        {
            throw new InvalidResultException('Input not string (JSON)');
        }
    }

    public function load(array $array)
    {
        if(isset($array['signal']) && $array['signal'] === 'authenticate')
        {
            throw new AuthenticateException;
        }
        else
        {
            foreach($array as $key => $value)
            {
                $this->{$key} = $value;
            }
        }
    }

    public function get($key)
    {
        $path = Key::decode($key);

        return array_reduce($path, function($prev, $now)
        {
            if($now === Key::DEFAULT_VARIABLE)
            {
                return $prev;
            }
            else
            {
                if($prev)
                {
                    if(is_array($prev))
                    {
                        return isset($prev[$now]) ? $prev[$now] : null;
                    }
                    else
                    {
                        return isset($prev->$now) ? $prev->$now : null;
                    }
                }
                else
                {
                    return null;
                }
            }
        }, $this->data);
    }

    public function remove($key)
    {
        if(isset($this->data))
        {
            list($reducer, $container, $variable) = Key::decode($key);

            if(isset($this->data->{$reducer}) && isset($this->data->{$reducer}->{$container}) && isset($this->data->{$reducer}->{$container}->{$variable}))
            {
                unset($this->data->{$reducer}->{$container}->{$variable});
            }
            else if(isset($this->data->{$reducer}) && isset($this->data->{$reducer}->{$container}))
            {
                unset($this->data->{$reducer}->{$container});
            }
            else if(isset($this->data->{$reducer}))
            {
                unset($this->data->{$reducer});
            }
        }
    }
}
